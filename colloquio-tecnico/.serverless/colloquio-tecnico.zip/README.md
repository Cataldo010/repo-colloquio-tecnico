# Colloqui Tecnico 
Piccolomo Cataldo - Omninext <br>
Deadline Sabato 20 Luglio

## Obiettivo

Implementare delle Rest API per la creazione e visualizzazione del modello user, In particolare dovrai creare i seguenti endpoint con i rispettivi metodi per la scrittura/lettura sul db:
- createUser
- getUserById

## Servizi AWS
- Lambda Function
- DynamoDB
- API Gateway

## Framework 
- Flask
- Serverless

## Github
[Colloqui-tecnico](https://link-url-here.org)

## Come ho lavorato

### Lunedi
Dopo aver ricevuto per email la traccia ho iniziato a dare un occhiata a quelle che erano le documentazioni presenti nell'email.
### Martedi
Ho creato l'account free di AWS e ho iniziato a mettere mano alle Lambda function
in seguito ho visto DynamoDB
### Mercoledi
Ho creato delle Api con API gateway. Ho iniziato a studiare la documetazion di Serverless Freamework per capire cosa facesse e come utilizzarlo, ho avviato un primo progetto.
### Giovedi
Ho dedicato tutta la giornata a studiarmi Flask e a mettere mano a python dato che non lo usavo da qualche mese
### Venerdi e Sabato
Ho messo finamente messo mano a creare le api, ho riscontrato alcuni problemi nella configurazione e nel far partire il tutto. Per semplicita ho testato le api con Postman 